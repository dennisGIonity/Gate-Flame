/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Gate^Flame Application Main
 */

import React, { useState, useEffect } from 'react';
import { AppViewMode, SystemTelemetry, ThreatLogEntry, ConnectedClient, IonityUserAccount } from './types';
import { INITIAL_TELEMETRY, MOCK_THREAT_LOGS, MOCK_CLIENTS, INITIAL_USER_ACCOUNT } from './data/mockData';
import { Header } from './components/Header';
import { MobileDashboard } from './components/MobileDashboard';
import { DeviceOnboardingSimulator } from './components/DeviceOnboardingSimulator';
import { ServerSyncArchitecture } from './components/ServerSyncArchitecture';
import { DeploymentScriptViewer } from './components/DeploymentScriptViewer';
import { FutureFeatureRoadmap } from './components/FutureFeatureRoadmap';
import { ExportPackagingCenter } from './components/ExportPackagingCenter';
import { Footer } from './components/Footer';

export default function App() {
  const [currentView, setCurrentView] = useState<AppViewMode>('mobile_apk');
  const [telemetry, setTelemetry] = useState<SystemTelemetry>(INITIAL_TELEMETRY);
  const [threatLogs, setThreatLogs] = useState<ThreatLogEntry[]>(MOCK_THREAT_LOGS);
  const [clients] = useState<ConnectedClient[]>(MOCK_CLIENTS);
  const [userAccount, setUserAccount] = useState<IonityUserAccount>(INITIAL_USER_ACCOUNT);

  // Background real-time query simulation loop
  useEffect(() => {
    const interval = setInterval(() => {
      if (telemetry.protectionStatus !== 'active') return;

      const increment = Math.floor(Math.random() * 4) + 1; // 1-4 new queries
      const blockedIncrement = Math.random() < 0.37 ? 1 : 0; // ~37.1% blocked

      setTelemetry((prev) => {
        const newTotal = prev.totalQueriesToday + increment;
        const newBlocked = prev.queriesBlockedToday + blockedIncrement;
        const newPercentage = Number(((newBlocked / newTotal) * 100).toFixed(1));
        const newSavedMB = Number((prev.dataSavedMB + (blockedIncrement * 0.12)).toFixed(1));

        return {
          ...prev,
          totalQueriesToday: newTotal,
          queriesBlockedToday: newBlocked,
          blockPercentage: newPercentage,
          dataSavedMB: newSavedMB,
        };
      });

      // Add dynamic threat log if a query was blocked
      if (blockedIncrement > 0) {
        const sampleDomains = [
          'telemetry.smart-tv.samsungcloud.com',
          'trackers.ads-network.io',
          'analytics.windows-telemetry.com',
          'beacon.evil-domain-phishing.xyz',
          'adservice.google.com/pagead',
          'crypto-miner.pool-hash.top',
        ];
        const sampleClients = [
          'Living Room Smart TV 75"',
          'Dennis-MacBook-Pro',
          'Office-Workstation-04',
          'Guest-Android-Phone',
        ];
        const categories: ThreatLogEntry['category'][] = [
          'Telemetry', 'Ad Tracker', 'Phishing', 'Cryptojacking', 'Adult / Gambling'
        ];

        const now = new Date();
        const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

        const newLog: ThreatLogEntry = {
          id: `log-${Date.now()}`,
          timestamp: timeStr,
          domain: sampleDomains[Math.floor(Math.random() * sampleDomains.length)],
          clientIp: '192.168.1.112',
          clientName: sampleClients[Math.floor(Math.random() * sampleClients.length)],
          category: categories[Math.floor(Math.random() * categories.length)],
          action: 'Blocked',
          severity: 'high',
        };

        setThreatLogs((prev) => [newLog, ...prev.slice(0, 19)]);
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [telemetry.protectionStatus]);

  const handlePauseProtection = (durationMinutes: number) => {
    setTelemetry((prev) => ({
      ...prev,
      protectionStatus: 'paused',
      pauseTimeRemainingSeconds: durationMinutes * 60,
    }));
  };

  const handleResumeProtection = () => {
    setTelemetry((prev) => ({
      ...prev,
      protectionStatus: 'active',
      pauseTimeRemainingSeconds: 0,
    }));
  };

  const handleAddWhitelistDomain = (domain: string) => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    const newLog: ThreatLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: timeStr,
      domain,
      clientIp: '192.168.1.105',
      clientName: 'Gate^Flame-Node-Primary',
      category: 'Ad Tracker',
      action: 'Whitelisted',
      severity: 'low',
    };

    setThreatLogs((prev) => [newLog, ...prev]);
  };

  const handleRefreshGravity = () => {
    setTelemetry((prev) => ({
      ...prev,
      domainsOnGravity: prev.domainsOnGravity + 1420,
    }));
  };

  const handleRebootDevice = () => {
    setTelemetry((prev) => ({
      ...prev,
      protectionStatus: 'initializing',
    }));

    setTimeout(() => {
      setTelemetry((prev) => ({
        ...prev,
        protectionStatus: 'active',
      }));
    }, 3000);
  };

  const handleUpdateUserAccount = (updated: Partial<IonityUserAccount>) => {
    setUserAccount((prev) => ({ ...prev, ...updated }));
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-gray-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Header Bar */}
      <Header
        currentView={currentView}
        onSelectView={setCurrentView}
        protectionActive={telemetry.protectionStatus === 'active'}
        totalBlocked={telemetry.queriesBlockedToday}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {currentView === 'mobile_apk' && (
          <MobileDashboard
            telemetry={telemetry}
            threatLogs={threatLogs}
            clients={clients}
            userAccount={userAccount}
            onPauseProtection={handlePauseProtection}
            onResumeProtection={handleResumeProtection}
            onAddWhitelistDomain={handleAddWhitelistDomain}
            onRefreshGravity={handleRefreshGravity}
            onRebootDevice={handleRebootDevice}
          />
        )}

        {currentView === 'device_kiosk' && (
          <DeviceOnboardingSimulator
            telemetry={telemetry}
            onOnboardingComplete={handleResumeProtection}
          />
        )}

        {currentView === 'server_sync' && (
          <ServerSyncArchitecture
            userAccount={userAccount}
            onUpdateUserAccount={handleUpdateUserAccount}
          />
        )}

        {currentView === 'scripts_bom' && (
          <DeploymentScriptViewer />
        )}

        {currentView === 'future_roadmap' && (
          <FutureFeatureRoadmap />
        )}

        {currentView === 'package_export' && (
          <ExportPackagingCenter />
        )}
      </main>

      {/* Footer Bar */}
      <Footer />
    </div>
  );
}
