/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Deployment Script Suite & BOM Calculator
 */

import React, { useState } from 'react';
import { 
  SCRIPT_AUTOPILOT, SCRIPT_DEPLOY, SCRIPT_UNBOUND, SCRIPT_PADD, HARDWARE_TIERS 
} from '../data/mockData';
import { Terminal, Copy, Check, Download, Calculator, ShieldCheck, FileText } from 'lucide-react';

export const DeploymentScriptViewer: React.FC = () => {
  const [activeScript, setActiveScript] = useState<'autopilot' | 'deploy' | 'unbound' | 'padd'>('autopilot');
  const [copied, setCopied] = useState(false);

  const getScriptContent = () => {
    switch (activeScript) {
      case 'autopilot': return { name: 'network_autopilot.sh', code: SCRIPT_AUTOPILOT, desc: 'Autonomously detects internet uplink. Launches "PiHole_Config_Setup" failover hotspot if disconnected.' };
      case 'deploy': return { name: 'deploy_pihole.sh', code: SCRIPT_DEPLOY, desc: 'Unattended Pi-hole injector. Dynamically binds Ethernet RJ45 or Wi-Fi interfaces without interactive prompts.' };
      case 'unbound': return { name: 'install_unbound.sh', code: SCRIPT_UNBOUND, desc: 'Recursive DNS resolver. Direct root hints queries, eliminating upstream ISP or Google logging.' };
      case 'padd': return { name: 'install_padd.sh', code: SCRIPT_PADD, desc: 'Pi-hole Ad Detection Display (PADD) terminal kiosk launcher for physical 3.5" or 7" displays.' };
    }
  };

  const scriptObj = getScriptContent();

  const handleCopy = () => {
    navigator.clipboard.writeText(scriptObj.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const blob = new Blob([scriptObj.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = scriptObj.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="max-w-6xl mx-auto my-6 p-4 sm:p-6 bg-[#0B0F17] text-white rounded-3xl border border-cyan-500/30 shadow-2xl font-sans space-y-6">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Terminal className="w-6 h-6 text-purple-400" /> Gate^Flame Edge Device Scripts & Hardware BOM
          </h2>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Production-ready Bash deployment suite & Bill of Materials for Ionity Edge Nodes
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono bg-purple-950 text-purple-300 border border-purple-500/40 px-2.5 py-1 rounded-xl">
            Zero-Trust System Suite v0.1
          </span>
        </div>
      </div>

      {/* Script Tab Selector & Code Viewer */}
      <div className="bg-[#111827] rounded-2xl border border-gray-800 overflow-hidden font-mono">
        {/* Script Selection Bar */}
        <div className="flex items-center justify-between bg-[#0B0F17] px-4 py-3 border-b border-gray-800 overflow-x-auto gap-2">
          <div className="flex items-center gap-1.5 text-xs">
            <button
              onClick={() => setActiveScript('autopilot')}
              className={`px-3 py-1.5 rounded-xl border transition-all ${
                activeScript === 'autopilot'
                  ? 'bg-purple-600 text-white font-bold border-purple-400 shadow-md shadow-purple-600/20'
                  : 'bg-gray-900 text-gray-400 border-gray-800 hover:text-white'
              }`}
            >
              network_autopilot.sh
            </button>

            <button
              onClick={() => setActiveScript('deploy')}
              className={`px-3 py-1.5 rounded-xl border transition-all ${
                activeScript === 'deploy'
                  ? 'bg-purple-600 text-white font-bold border-purple-400 shadow-md shadow-purple-600/20'
                  : 'bg-gray-900 text-gray-400 border-gray-800 hover:text-white'
              }`}
            >
              deploy_pihole.sh
            </button>

            <button
              onClick={() => setActiveScript('unbound')}
              className={`px-3 py-1.5 rounded-xl border transition-all ${
                activeScript === 'unbound'
                  ? 'bg-purple-600 text-white font-bold border-purple-400 shadow-md shadow-purple-600/20'
                  : 'bg-gray-900 text-gray-400 border-gray-800 hover:text-white'
              }`}
            >
              install_unbound.sh
            </button>

            <button
              onClick={() => setActiveScript('padd')}
              className={`px-3 py-1.5 rounded-xl border transition-all ${
                activeScript === 'padd'
                  ? 'bg-purple-600 text-white font-bold border-purple-400 shadow-md shadow-purple-600/20'
                  : 'bg-gray-900 text-gray-400 border-gray-800 hover:text-white'
              }`}
            >
              install_padd.sh
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="bg-gray-800 hover:bg-gray-700 text-cyan-300 px-3 py-1.5 rounded-xl text-xs font-bold border border-gray-700 transition-all flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied!' : 'Copy Script'}
            </button>

            <button
              onClick={handleDownload}
              className="bg-purple-600 hover:bg-purple-500 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-purple-600/20"
            >
              <Download className="w-3.5 h-3.5" /> Download
            </button>
          </div>
        </div>

        {/* Script Description Banner */}
        <div className="bg-purple-950/30 p-3 px-4 border-b border-gray-800 text-xs text-purple-200">
          <strong>Purpose:</strong> {scriptObj.desc}
        </div>

        {/* Code Content */}
        <div className="p-4 bg-[#080B11] text-cyan-300 text-xs overflow-x-auto leading-relaxed max-h-96">
          <pre>{scriptObj.code}</pre>
        </div>
      </div>

      {/* Hardware Bill of Materials (BOM) Calculator */}
      <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-4 font-mono text-xs">
        <h3 className="font-bold text-amber-400 flex items-center gap-2">
          <Calculator className="w-4 h-4" /> Bill of Materials (BOM) & Unit Economics (ZAR)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-800 text-gray-400 text-[11px]">
                <th className="py-2 px-3">Device Model</th>
                <th className="py-2 px-3">Core Compute Platform</th>
                <th className="py-2 px-3">Primary Features</th>
                <th className="py-2 px-3">Base Hardware Cost</th>
                <th className="py-2 px-3">Retail Price (+25% Margin)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800 text-gray-200">
              {HARDWARE_TIERS.map((tier) => (
                <tr key={tier.id} className="hover:bg-gray-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-white">{tier.name.split(':')[1]}</td>
                  <td className="py-2.5 px-3 text-cyan-300">{tier.cpu.split('@')[0]}</td>
                  <td className="py-2.5 px-3 text-gray-300">{tier.display}</td>
                  <td className="py-2.5 px-3 text-gray-400">R{tier.baseCostZAR.toFixed(2)}</td>
                  <td className="py-2.5 px-3 font-bold text-amber-400">R{tier.retailPriceZAR.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
