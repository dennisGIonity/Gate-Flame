/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Physical Device Kiosk & Onboarding Flow Simulator
 */

import React, { useState, useEffect } from 'react';
import { OnboardingStep, NetworkOption, HardwareTierId, SystemTelemetry } from '../types';
import { HARDWARE_TIERS, MOCK_NETWORKS } from '../data/mockData';
import { 
  Power, ShieldCheck, Wifi, Cable, Key, CheckCircle2, 
  ArrowRight, RefreshCw, BarChart3, ChevronLeft, ChevronRight, SlidersHorizontal, Lock, Cpu
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

interface DeviceOnboardingSimulatorProps {
  telemetry: SystemTelemetry;
  onOnboardingComplete: () => void;
}

export const DeviceOnboardingSimulator: React.FC<DeviceOnboardingSimulatorProps> = ({
  telemetry,
  onOnboardingComplete,
}) => {
  const [selectedTier, setSelectedTier] = useState<HardwareTierId>('tier3_visual');
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('power_on');
  const [bootProgress, setBootProgress] = useState(0);

  // Network selection state
  const [selectedNetwork, setSelectedNetwork] = useState<NetworkOption | null>(MOCK_NETWORKS[0]);
  const [networkPassword, setNetworkPassword] = useState('SecurePass2026!');
  
  // User login state
  const [userEmail, setUserEmail] = useState('dennis.ionity.world@gmail.com');
  const [userPassword, setUserPassword] = useState('••••••••••••');

  // Initialization loading status
  const [initStage, setInitStage] = useState(0);
  const initMessages = [
    'Detecting active network interface (Ethernet/Wi-Fi)...',
    'Binding setupVars.conf & Unattended Pi-hole engine...',
    'Loading Unbound Recursive DNS Root Hints (named.root)...',
    'Ingesting 6,755,558 Gravity domains from global repositories...',
    'Activating mTLS zero-trust tunnel to Ionity Central Server...',
    'Gate^Flame Security Node Activated Successfully!'
  ];

  // Touch Screen Swipe/Tab Index (0: Queries, 1: Blocked, 2: Savings, 3: Clients, 4: Settings)
  const [touchTab, setTouchTab] = useState<number>(0);

  // Boot progress timer
  useEffect(() => {
    if (currentStep === 'power_on') {
      setBootProgress(0);
      const interval = setInterval(() => {
        setBootProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            setCurrentStep('welcome_greeting');
            return 100;
          }
          return prev + 20;
        });
      }, 300);
      return () => clearInterval(interval);
    }
  }, [currentStep]);

  // Initialization progress timer
  useEffect(() => {
    if (currentStep === 'initializing') {
      setInitStage(0);
      const interval = setInterval(() => {
        setInitStage((prev) => {
          if (prev >= initMessages.length - 1) {
            clearInterval(interval);
            setTimeout(() => {
              setCurrentStep('infographic_kiosk');
              onOnboardingComplete();
            }, 800);
            return initMessages.length - 1;
          }
          return prev + 1;
        });
      }, 700);
      return () => clearInterval(interval);
    }
  }, [currentStep]);

  const activeTierObj = HARDWARE_TIERS.find((t) => t.id === selectedTier) || HARDWARE_TIERS[2];

  const handleNetworkSubmit = () => {
    if (!selectedNetwork) return;
    if (selectedNetwork.type === 'ethernet') {
      // Wired cable bypasses Wi-Fi password prompt
      setCurrentStep('user_auth');
    } else {
      setCurrentStep('network_auth');
    }
  };

  const handleNetworkAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep('user_auth');
  };

  const handleUserAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep('initializing');
  };

  const nextTouchTab = () => setTouchTab((prev) => (prev + 1) % 5);
  const prevTouchTab = () => setTouchTab((prev) => (prev - 1 + 5) % 5);

  return (
    <div className="max-w-4xl mx-auto my-6 p-4 sm:p-6 bg-[#0B0F17] text-white rounded-3xl border border-cyan-500/30 shadow-2xl font-sans">
      {/* Top Header Controls: Tier Selection & Reset */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-800">
        <div>
          <h2 className="text-lg font-bold font-sans text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" /> Physical Node Kiosk & Onboarding Simulator
          </h2>
          <p className="text-xs text-gray-400 font-mono">
            Simulates the Raspberry Pi / Orange Pi touchscreen display onboarding sequence
          </p>
        </div>

        {/* Hardware Tier Selector */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-gray-400">Target Hardware:</span>
          <select
            value={selectedTier}
            onChange={(e) => {
              setSelectedTier(e.target.value as HardwareTierId);
              setCurrentStep('power_on');
            }}
            className="bg-[#111827] border border-cyan-500/40 text-cyan-300 px-3 py-1.5 rounded-xl font-bold focus:outline-none"
          >
            {HARDWARE_TIERS.map((tier) => (
              <option key={tier.id} value={tier.id}>
                {tier.name}
              </option>
            ))}
          </select>
          <button
            onClick={() => setCurrentStep('power_on')}
            className="p-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg border border-gray-700 transition-all"
            title="Reboot Node"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Hardware Frame Simulator Shell */}
      <div className="mt-6 relative">
        {/* Physical Enclosure Frame (Simulating 3.5" or 7" IPS Touchscreen) */}
        <div className="bg-[#111827] p-4 sm:p-8 rounded-[28px] border-4 border-gray-800 shadow-2xl relative overflow-hidden min-h-[460px] flex flex-col justify-between">
          {/* Top Touchscreen Bezel Header */}
          <div className="flex justify-between items-center text-xs font-mono text-gray-400 pb-3 border-b border-gray-800">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Gate^Flame Touch Kiosk</span>
              <span className={`text-[10px] px-2 py-0.5 rounded border ${activeTierObj.badgeColor}`}>
                {activeTierObj.name.split(':')[0]}
              </span>
            </div>
            <div className="text-[10px] text-gray-500">
              Ionity Global (Pty) Ltd &bull; Registered Mark POL 986 AED
            </div>
          </div>

          {/* STEP 1: PLUG IN & TURN ON */}
          {currentStep === 'power_on' && (
            <div className="my-auto text-center space-y-6 py-8">
              <div className="inline-flex p-4 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 animate-pulse">
                <Power className="w-12 h-12" />
              </div>
              <div>
                <h3 className="text-2xl font-extrabold text-white font-sans">
                  PLUGGED IN & POWERED ON
                </h3>
                <p className="text-sm text-gray-400 font-mono mt-2">
                  System POST Diagnostics & Booting Kernel...
                </p>
              </div>

              {/* Boot Progress Bar */}
              <div className="max-w-md mx-auto space-y-2 font-mono">
                <div className="w-full bg-gray-800 h-3 rounded-full overflow-hidden border border-gray-700">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 h-full transition-all duration-300"
                    style={{ width: `${bootProgress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-[11px] text-gray-400">
                  <span>ARM64 CPU Init</span>
                  <span>{bootProgress}%</span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: GREETING */}
          {currentStep === 'welcome_greeting' && (
            <div className="my-auto text-center space-y-6 py-6 font-mono">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-900 flex items-center justify-center text-white shadow-xl shadow-cyan-500/20 border border-cyan-400/40">
                <ShieldCheck className="w-10 h-10 text-cyan-200" />
              </div>
              <div>
                <h3 className="text-2xl font-extrabold text-white font-sans">
                  Gate<span className="text-cyan-400">^</span>Flame + Welcome
                </h3>
                <p className="text-xs text-gray-400 max-w-md mx-auto mt-2 leading-relaxed">
                  Enterprise-Grade DNS Security & Privacy Node by Ionity Global (Pty) Ltd. Zero-touch installation ready.
                </p>
              </div>

              <div className="p-3 bg-[#0B0F17] rounded-xl border border-gray-800 max-w-sm mx-auto text-left text-[11px] space-y-1 text-gray-300">
                <p><strong className="text-cyan-400">Hardware Profile:</strong> {activeTierObj.name}</p>
                <p><strong className="text-cyan-400">Processor:</strong> {activeTierObj.cpu}</p>
                <p><strong className="text-cyan-400">Max Capacity:</strong> ~{activeTierObj.qps} QPS / {activeTierObj.maxClients} Clients</p>
              </div>

              <button
                onClick={() => setCurrentStep('network_selection')}
                className="bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold px-6 py-3 rounded-xl text-sm transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 mx-auto"
              >
                Start Network Onboarding Setup <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 3: NETWORK SELECTION (Show Cable & Wi-Fi) */}
          {currentStep === 'network_selection' && (
            <div className="my-auto space-y-4 py-4 font-mono">
              <div className="text-center">
                <h3 className="text-lg font-bold text-white font-sans flex items-center justify-center gap-2">
                  <Wifi className="w-5 h-5 text-cyan-400" /> Select Network Uplink Source
                </h3>
                <p className="text-xs text-gray-400 mt-1">
                  Detecting Ethernet RJ45 Cable & Available Wi-Fi Networks
                </p>
              </div>

              {/* Network Options List */}
              <div className="space-y-2.5 max-w-lg mx-auto">
                {MOCK_NETWORKS.map((net) => {
                  const isSelected = selectedNetwork?.id === net.id;
                  return (
                    <div
                      key={net.id}
                      onClick={() => setSelectedNetwork(net)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-cyan-950/80 border-cyan-400 text-white shadow-md shadow-cyan-500/10'
                          : 'bg-[#0B0F17] border-gray-800 text-gray-300 hover:border-gray-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-xl ${net.type === 'ethernet' ? 'bg-amber-950/80 text-amber-400' : 'bg-cyan-950/80 text-cyan-400'}`}>
                          {net.type === 'ethernet' ? <Cable className="w-5 h-5" /> : <Wifi className="w-5 h-5" />}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-2">
                            {net.ssid}
                            {net.type === 'ethernet' && (
                              <span className="text-[9px] bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/30">
                                PRIORITY WIRED
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-gray-400 mt-0.5">
                            {net.type === 'ethernet' ? 'LAN Interface (1000Mbps)' : `${net.frequency} • Signal: ${net.signalStrength}%`}
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        {isSelected ? (
                          <CheckCircle2 className="w-5 h-5 text-cyan-400" />
                        ) : (
                          <span className="text-[10px] text-gray-500">Tap to Select</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={handleNetworkSubmit}
                  disabled={!selectedNetwork}
                  className="bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold px-6 py-2.5 rounded-xl text-xs transition-all shadow-lg shadow-cyan-500/20 inline-flex items-center gap-2"
                >
                  Continue with Selected Network <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: NETWORK AUTH (Password for Wi-Fi) */}
          {currentStep === 'network_auth' && (
            <div className="my-auto space-y-4 py-4 max-w-md mx-auto font-mono">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto rounded-xl bg-cyan-950 text-cyan-400 flex items-center justify-center mb-2">
                  <Key className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white font-sans">
                  Network Authentication
                </h3>
                <p className="text-xs text-gray-400 mt-1">
                  Connecting to <strong className="text-cyan-400">{selectedNetwork?.ssid}</strong>
                </p>
              </div>

              <form onSubmit={handleNetworkAuthSubmit} className="space-y-3 bg-[#0B0F17] p-4 rounded-2xl border border-gray-800">
                <div>
                  <label className="block text-[11px] text-gray-300 mb-1">Enter Wi-Fi Password:</label>
                  <input
                    type="password"
                    value={networkPassword}
                    onChange={(e) => setNetworkPassword(e.target.value)}
                    required
                    className="w-full bg-[#111827] border border-gray-700 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setCurrentStep('network_selection')}
                    className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 py-2 rounded-xl text-xs font-mono"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-cyan-500 hover:bg-cyan-400 text-black font-bold py-2 rounded-xl text-xs font-mono transition-all"
                  >
                    Authenticate Network
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* STEP 5: USER & DEVICE AUTH */}
          {currentStep === 'user_auth' && (
            <div className="my-auto space-y-4 py-4 max-w-md mx-auto font-mono">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 text-black flex items-center justify-center mb-2 font-bold">
                  <Lock className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white font-sans">
                  Gate<span className="text-cyan-400">^</span>Flame User Authentication
                </h3>
                <p className="text-xs text-gray-400 mt-1">
                  Sync physical node with Ionity account for warranty & Gravity updates
                </p>
              </div>

              <form onSubmit={handleUserAuthSubmit} className="space-y-3 bg-[#0B0F17] p-4 rounded-2xl border border-gray-800">
                <div>
                  <label className="block text-[11px] text-gray-300 mb-1">Ionity Account Email:</label>
                  <input
                    type="email"
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                    required
                    className="w-full bg-[#111827] border border-gray-700 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-gray-300 mb-1">Account Password:</label>
                  <input
                    type="password"
                    value={userPassword}
                    onChange={(e) => setUserPassword(e.target.value)}
                    required
                    className="w-full bg-[#111827] border border-gray-700 rounded-xl px-3 py-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold py-2.5 rounded-xl text-xs font-mono shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" /> Link Node & Activate Full Protection
                </button>
              </form>
            </div>
          )}

          {/* STEP 6: PROTECTION INITIALIZING */}
          {currentStep === 'initializing' && (
            <div className="my-auto text-center space-y-6 py-8 font-mono">
              <div className="p-4 rounded-2xl bg-cyan-950 text-cyan-400 inline-block">
                <RefreshCw className="w-10 h-10 animate-spin" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-sans">
                  Initializing Gate^Flame Shield Engine
                </h3>
                <p className="text-xs text-emerald-400 font-mono mt-1">
                  Zero-Touch Automated Bootstrapping in Progress
                </p>
              </div>

              <div className="max-w-md mx-auto bg-[#0B0F17] p-4 rounded-2xl border border-gray-800 text-left text-xs font-mono space-y-2 text-gray-300">
                {initMessages.map((msg, idx) => (
                  <div key={idx} className={`flex items-center gap-2 ${idx <= initStage ? 'text-cyan-300' : 'text-gray-600'}`}>
                    <span className={idx <= initStage ? 'text-emerald-400' : 'text-gray-700'}>
                      {idx <= initStage ? '✓' : '○'}
                    </span>
                    <span>{msg}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 7: INFOGRAPHIC TOUCH KIOSK (Swipe Left/Right) */}
          {currentStep === 'infographic_kiosk' && (
            <div className="space-y-4 font-mono my-auto">
              {/* Swipeable Tabs Header */}
              <div className="flex justify-between items-center bg-[#0B0F17] p-2 rounded-2xl border border-gray-800 text-xs">
                <button
                  onClick={prevTouchTab}
                  className="p-1.5 bg-gray-800 hover:bg-gray-700 text-cyan-400 rounded-xl"
                  title="Swipe Left"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="flex gap-1.5 overflow-x-auto text-[11px]">
                  {['01 Queries', '02 Sinkhole', '03 Savings', '04 Clients', '05 Settings'].map((tabLabel, idx) => (
                    <button
                      key={tabLabel}
                      onClick={() => setTouchTab(idx)}
                      className={`px-2.5 py-1 rounded-xl border transition-all ${
                        touchTab === idx
                          ? 'bg-cyan-500 text-black font-extrabold border-cyan-400'
                          : 'bg-gray-900 text-gray-400 border-gray-800 hover:text-white'
                      }`}
                    >
                      {tabLabel}
                    </button>
                  ))}
                </div>

                <button
                  onClick={nextTouchTab}
                  className="p-1.5 bg-gray-800 hover:bg-gray-700 text-cyan-400 rounded-xl"
                  title="Swipe Right"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Infographic Touch Screen 1: Total Queries */}
              {touchTab === 0 && (
                <div className="bg-[#0B0F17] p-5 rounded-2xl border border-blue-500/40 text-center space-y-3">
                  <div className="text-xs uppercase font-bold text-blue-400 tracking-wider">
                    Infographic Screen 1 / 5: Total Network Queries
                  </div>
                  <div className="text-4xl font-extrabold text-blue-400 tracking-tight">
                    {telemetry.totalQueriesToday.toLocaleString()}
                  </div>
                  <p className="text-xs text-gray-300">
                    Sustained query load processed across local network clients. Zero latency overhead.
                  </p>
                </div>
              )}

              {/* Infographic Touch Screen 2: Blocked Threat Counter */}
              {touchTab === 1 && (
                <div className="bg-[#0B0F17] p-5 rounded-2xl border border-red-500/40 text-center space-y-3">
                  <div className="text-xs uppercase font-bold text-red-400 tracking-wider">
                    Infographic Screen 2 / 5: Sinkholed Threat Count
                  </div>
                  <div className="text-4xl font-extrabold text-red-400 tracking-tight">
                    {telemetry.queriesBlockedToday.toLocaleString()}
                  </div>
                  <p className="text-xs text-gray-300">
                    Proactively neutralized malware, phishing, ad-trackers, and smart TV telemetry.
                  </p>
                </div>
              )}

              {/* Infographic Touch Screen 3: Data Efficiency */}
              {touchTab === 2 && (
                <div className="bg-[#0B0F17] p-5 rounded-2xl border border-amber-500/40 text-center space-y-3">
                  <div className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                    Infographic Screen 3 / 5: Data Waste Reduction
                  </div>
                  <div className="text-4xl font-extrabold text-amber-400 tracking-tight">
                    37.1% Efficiency
                  </div>
                  <p className="text-xs text-emerald-400">
                    1,420.5 MB of unwanted background data waste eliminated today.
                  </p>
                </div>
              )}

              {/* Infographic Touch Screen 4: Active Clients Chart */}
              {touchTab === 3 && (
                <div className="bg-[#0B0F17] p-4 rounded-2xl border border-purple-500/40 space-y-2">
                  <div className="text-xs uppercase font-bold text-purple-400 text-center">
                    Infographic Screen 4 / 5: Active Client Nodes (24 Devices)
                  </div>
                  <div className="h-36 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[
                        { name: 'Smart TV', count: 8900 },
                        { name: 'MacBook', count: 12450 },
                        { name: 'Workstation', count: 9100 },
                        { name: 'Phones', count: 4300 },
                        { name: 'Tablets', count: 2680 },
                      ]}>
                        <XAxis dataKey="name" stroke="#9CA3AF" fontSize={10} />
                        <YAxis stroke="#9CA3AF" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#111827', borderColor: '#374151' }} />
                        <Bar dataKey="count" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* Infographic Touch Screen 5: Settings Tab */}
              {touchTab === 4 && (
                <div className="bg-[#0B0F17] p-4 rounded-2xl border border-emerald-500/40 space-y-3 text-xs">
                  <div className="text-xs font-bold text-emerald-400 text-center flex items-center justify-center gap-1.5">
                    <SlidersHorizontal className="w-4 h-4" /> Infographic Screen 5 / 5: Local Node Settings
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="p-2.5 bg-[#111827] rounded-xl border border-gray-800">
                      <div className="text-gray-400">DNS Resolver:</div>
                      <div className="text-cyan-300 font-bold">Unbound Recursive</div>
                    </div>
                    <div className="p-2.5 bg-[#111827] rounded-xl border border-gray-800">
                      <div className="text-gray-400">Active Uplink:</div>
                      <div className="text-amber-400 font-bold">{selectedNetwork?.ssid}</div>
                    </div>
                  </div>

                  <div className="p-2.5 bg-[#111827] rounded-xl border border-gray-800 text-[10px] text-gray-400 space-y-1">
                    <p><strong className="text-white">Ionity Global (Pty) Ltd Warranty:</strong> Active (R45/mo)</p>
                    <p><strong className="text-white">Hotspot Failover:</strong> SSID PiHole_Config_Setup Ready</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Bottom Kiosk Status Footer */}
          <div className="pt-3 border-t border-gray-800 flex justify-between items-center text-[10px] font-mono text-gray-400">
            <span>Uptime: 24h 00m 20s</span>
            <span>Ionity Gate^Flame Node</span>
            <span>IP: 192.168.1.105</span>
          </div>
        </div>
      </div>
    </div>
  );
};
