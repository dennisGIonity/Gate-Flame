/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Export & Packaging Center (APK, HTML, Node Script Bundles)
 */

import React, { useState } from 'react';
import { 
  Package, Download, Smartphone, Globe, Terminal, FileCode, 
  CheckCircle2, FolderArchive, Layers, ExternalLink, HelpCircle, Lock 
} from 'lucide-react';
import { SCRIPT_AUTOPILOT, SCRIPT_DEPLOY, SCRIPT_UNBOUND, SCRIPT_PADD } from '../data/mockData';

export const ExportPackagingCenter: React.FC = () => {
  const [htmlGenerated, setHtmlGenerated] = useState(false);
  const [apkManifestGenerated, setApkManifestGenerated] = useState(false);
  const [piBundleGenerated, setPiBundleGenerated] = useState(false);

  // Download Standalone Single-File HTML Package
  const handleDownloadStandaloneHtml = () => {
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gate^Flame Mobile App & Kiosk — Ionity Global (Pty) Ltd</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { background-color: #0B0F17; color: #F3F4F6; font-family: ui-sans-serif, system-ui, sans-serif; }
  </style>
</head>
<body class="p-4 sm:p-8">
  <div class="max-w-md mx-auto bg-[#111827] p-6 rounded-3xl border-2 border-cyan-500/40 shadow-2xl space-y-4">
    <div class="flex items-center justify-between border-b border-gray-800 pb-3">
      <div>
        <h1 class="text-xl font-extrabold text-white">Gate<span class="text-cyan-400">^</span>Flame™</h1>
        <p class="text-xs text-gray-400 font-mono">Ionity Global (Pty) Ltd &bull; POL 986 AED</p>
      </div>
      <span class="bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded text-xs font-mono border border-emerald-500/40">Shield Active</span>
    </div>

    <div class="grid grid-cols-2 gap-3 font-mono text-center">
      <div class="bg-[#0B0F17] p-3 rounded-xl border border-blue-500/30">
        <div class="text-[10px] text-blue-400 uppercase">Total Queries</div>
        <div class="text-xl font-bold text-blue-400">38,851</div>
      </div>
      <div class="bg-[#0B0F17] p-3 rounded-xl border border-red-500/30">
        <div class="text-[10px] text-red-400 uppercase">Queries Blocked</div>
        <div class="text-xl font-bold text-red-400">14,397</div>
      </div>
      <div class="bg-[#0B0F17] p-3 rounded-xl border border-amber-500/30">
        <div class="text-[10px] text-amber-400 uppercase">Block Rate</div>
        <div class="text-xl font-bold text-amber-400">37.1%</div>
      </div>
      <div class="bg-[#0B0F17] p-3 rounded-xl border border-emerald-500/30">
        <div class="text-[10px] text-emerald-400 uppercase">Gravity Count</div>
        <div class="text-xl font-bold text-emerald-400">6.75M</div>
      </div>
    </div>

    <div class="p-3 bg-[#0B0F17] rounded-xl border border-gray-800 text-xs font-mono space-y-1">
      <p><strong class="text-cyan-400">Linked Device MAC:</strong> DC:A6:32:88:14:2F</p>
      <p><strong class="text-cyan-400">Subscription:</strong> R45/mo Managed Warranty</p>
      <p><strong class="text-cyan-400">Recursive Resolver:</strong> Unbound 127.0.0.1#5335</p>
    </div>

    <div class="text-center text-[10px] font-mono text-gray-500 pt-2 border-t border-gray-800">
      &copy; 2026 Ionity Global (Pty) Ltd. Standalone Web Bundle.
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gateflame_mobile_app.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setHtmlGenerated(true);
  };

  // Download Capacitor Android Manifest & Build Package Config
  const handleDownloadApkPackageConfig = () => {
    const capacitorConfig = {
      appId: "com.ionity.gateflame.app",
      appName: "Gate^Flame Mobile",
      webDir: "dist",
      bundledWebRuntime: false,
      server: {
        androidScheme: "https"
      },
      plugins: {
        SplashScreen: {
          launchShowDuration: 2000,
          backgroundColor: "#0B0F17"
        }
      }
    };

    const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.ionity.gateflame.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Gate^Flame"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">

        <activity
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:name=".MainActivity"
            android:label="Gate^Flame"
            android:exported="true"
            android:theme="@style/AppTheme.NoActionBarLaunch">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

    const packageInstructions = `# Ionity Global (Pty) Ltd — Gate^Flame Android APK Build Manual

## Prerequisites:
1. Node.js 18+ and Android Studio with SDK 34+.

## Build Steps:
1. Run npm build in this project directory:
   npm run build

2. Initialize Capacitor Android Wrapper:
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Gate^Flame" "com.ionity.gateflame.app" --web-dir dist
   npx cap add android
   npx cap copy android

3. Compile Release APK:
   npx cap open android
   Or run directly via Gradle:
   cd android && ./gradlew assembleRelease

The compiled APK will be located at:
android/app/build/outputs/apk/release/app-release.apk
`;

    const blob = new Blob([packageInstructions], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gateflame_apk_build_guide.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setApkManifestGenerated(true);
  };

  // Download Combined Raspberry Pi / Orange Pi Shell Suite
  const handleDownloadPiBundleScript = () => {
    const combinedScript = `#!/bin/bash
# IONITY GLOBAL (Pty) Ltd — Gate^Flame Master Installation Suite
# Target Hardware: Orange Pi Zero 2W / RPi Zero 2 WH / RPi 5 AI HAT+

set -e

echo "=========================================================="
echo "   IONITY GLOBAL (Pty) Ltd — Gate^Flame Node Installer    "
echo "=========================================================="

# 1. Install Dependencies
apt-get update
apt-get install -y curl wget dnsmasq hostapd unbound fail2ban ufw

# 2. Deploy Network Autopilot
cat << 'EOF' > /usr/local/bin/network_autopilot.sh
${SCRIPT_AUTOPILOT}
EOF
chmod +x /usr/local/bin/network_autopilot.sh

# 3. Deploy Unattended Pi-hole Injector
mkdir -p /opt/scripts
cat << 'EOF' > /opt/scripts/deploy_pihole.sh
${SCRIPT_DEPLOY}
EOF
chmod +x /opt/scripts/deploy_pihole.sh

# 4. Deploy Unbound Recursive Resolver
cat << 'EOF' > /opt/scripts/install_unbound.sh
${SCRIPT_UNBOUND}
EOF
chmod +x /opt/scripts/install_unbound.sh

# 5. Deploy PADD Display Kiosk
cat << 'EOF' > /opt/scripts/install_padd.sh
${SCRIPT_PADD}
EOF
chmod +x /opt/scripts/install_padd.sh

echo "=========================================================="
echo "Gate^Flame Master Suite Installed Successfully in /opt/scripts"
echo "=========================================================="
`;

    const blob = new Blob([combinedScript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gateflame_master_installer.sh';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setPiBundleGenerated(true);
  };

  return (
    <div className="max-w-6xl mx-auto my-6 p-4 sm:p-6 bg-[#0B0F17] text-white rounded-3xl border border-cyan-500/30 shadow-2xl font-sans space-y-6">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-cyan-400" /> Export & Packaging Center (APK, Web & Edge Bundles)
          </h2>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Package and export the Gate^Flame system into APK binaries, standalone HTML5 files, and Raspberry Pi scripts
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 px-3 py-1 rounded-xl font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Commercial Package Ready
          </span>
        </div>
      </div>

      {/* Grid of Export Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
        {/* Package Option 1: Mobile APK Wrapper */}
        <div className="bg-[#111827] p-5 rounded-2xl border border-cyan-500/30 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-400 flex items-center justify-center font-bold">
              <Smartphone className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-sm font-bold text-white font-sans">Android APK Package Bundle</h3>
              <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                Contains AndroidManifest.xml, Capacitor wrapper config, and Gradle build script to compile <code className="text-cyan-300">gateflame.apk</code>.
              </p>
            </div>
          </div>

          <button
            onClick={handleDownloadApkPackageConfig}
            className="w-full bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold py-2.5 rounded-xl transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" /> Download APK Build Package
          </button>
        </div>

        {/* Package Option 2: Standalone HTML5 Bundle */}
        <div className="bg-[#111827] p-5 rounded-2xl border border-amber-500/30 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-950 text-amber-400 flex items-center justify-center font-bold">
              <Globe className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-sm font-bold text-white font-sans">Standalone HTML5 Web App</h3>
              <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                Self-contained HTML dashboard file that opens directly in any desktop or mobile browser without requiring a server setup.
              </p>
            </div>
          </div>

          <button
            onClick={handleDownloadStandaloneHtml}
            className="w-full bg-amber-500 hover:bg-amber-400 text-black font-extrabold py-2.5 rounded-xl transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" /> Download Standalone HTML
          </button>
        </div>

        {/* Package Option 3: Physical Node Shell Suite */}
        <div className="bg-[#111827] p-5 rounded-2xl border border-purple-500/30 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-purple-950 text-purple-400 flex items-center justify-center font-bold">
              <Terminal className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-sm font-bold text-white font-sans">Raspberry / Orange Pi Installer</h3>
              <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                Master Shell Script (<code className="text-purple-300">gateflame_master_installer.sh</code>) bundling Autopilot, Pi-hole Injector & Unbound.
              </p>
            </div>
          </div>

          <button
            onClick={handleDownloadPiBundleScript}
            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-extrabold py-2.5 rounded-xl transition-all shadow-lg shadow-purple-600/20 flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" /> Download Shell Installer
          </button>
        </div>
      </div>

      {/* AI Studio Export & Share Instructions Banner */}
      <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-3 font-mono text-xs">
        <h3 className="font-bold text-white flex items-center gap-2 text-sm">
          <FolderArchive className="w-4 h-4 text-cyan-400" /> Full Source Code & AI Studio Export Options
        </h3>

        <p className="text-gray-300 leading-relaxed">
          You can also export the full production codebase directly using the Google AI Studio top bar menu:
        </p>

        <ul className="list-disc list-inside space-y-1 text-gray-400">
          <li><strong className="text-white">Export as ZIP:</strong> Click the Settings / Export icon in the top right of AI Studio to download the entire repository as a ZIP.</li>
          <li><strong className="text-white">Deploy to GitHub:</strong> Link your GitHub account in AI Studio to push this repository directly to a new or existing GitHub project.</li>
          <li><strong className="text-white">Deploy to Cloud Run:</strong> Click the Deploy button to host the full-stack containerized app globally on Cloud Run.</li>
        </ul>
      </div>
    </div>
  );
};
