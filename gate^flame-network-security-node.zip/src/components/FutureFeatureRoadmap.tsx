/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Future Feature Expansion Roadmap (LATER Phase Features)
 */

import React, { useState } from 'react';
import { FutureFeatureModule } from '../types';
import { 
  Sparkles, ShieldCheck, Cpu, Layers, Lock, ToggleLeft, ToggleRight, 
  Hotel, Wifi, RefreshCw, AlertCircle, CheckCircle2, ChevronRight 
} from 'lucide-react';

const INITIAL_FUTURE_MODULES: FutureFeatureModule[] = [
  {
    id: 'ai_anomaly_detection',
    name: 'AI Sentinel Behavioral Anomaly Detection',
    category: 'AI & Intelligence',
    status: 'planned_later',
    description: 'Uses NPU on Raspberry Pi AI HAT+ (26 TOPS) to detect novel zero-day phishing patterns and botnet C&C behaviors without waiting for static blocklists.',
    targetHardware: 'Device 4 (RPi 5 16GB + AI HAT+)',
    enabledLater: false,
    docReference: 'ION-GF-STR-2026-009 (Section 2, Tier 4)',
  },
  {
    id: 'suricata_ids_ips',
    name: 'Suricata Intrusion Detection & Fail2Ban IPS',
    category: 'Network Security',
    status: 'planned_later',
    description: 'Deep-packet inspection for port scans, brute-force SSH attacks, and anomalous bandwidth exfiltration. Dynamically rewrites UFW firewall rules.',
    targetHardware: 'Device 2, Device 3 & Device 4',
    enabledLater: false,
    docReference: 'ION-GF-UC-2026-010 (Part 1, IPS)',
  },
  {
    id: 'captive_portal_mac_cloning',
    name: 'Hotspot Captive Portal MAC Bypasser & Hotel Nomad',
    category: 'Travel & Failover',
    status: 'planned_later',
    description: 'Allows travelers to SSH into the Zero 2 W node and clone a smartphone authenticated MAC address to bypass captive portals in hotels or public Wi-Fi.',
    targetHardware: 'Device 1 (Minimalist Travel Node)',
    enabledLater: false,
    docReference: 'ION-GF-PNP-2026-003 (Device 1)',
  },
  {
    id: 'hospitality_scada_grid',
    name: 'Hospitality Smart Room SCADA & Occupancy Grid',
    category: 'Hospitality SCADA',
    status: 'planned_later',
    description: 'Integrates room ESP32 microcontrollers for HVAC pre-cooling, water leak detection, door open alerts, and non-audio noise monitoring.',
    targetHardware: 'Project Root System [RPS01]',
    enabledLater: false,
    docReference: 'ION-GF-PDS-RPS01-2026-011 (Section A-E)',
  },
  {
    id: 'ota_firmware_signing',
    name: 'RSA/ECC Signed OTA Firmware & Rollback Engine',
    category: 'Enterprise Hardware',
    status: 'planned_later',
    description: 'HTTPS/MQTT TLS transport with RSA-2048 cryptographic signature verification before applying firmware updates with A/B partition recovery.',
    targetHardware: 'All Gate^Flame Hardware Tiers',
    enabledLater: false,
    docReference: 'ION-GF-GAP-2026-013 (Section 11.7)',
  },
  {
    id: 'esp8266_telemetry_hardware',
    name: 'ESP8266 Physical OLED Remote Telemetry Monitor',
    category: 'Enterprise Hardware',
    status: 'planned_later',
    description: 'Dedicated Wemos D1 Mini + SSD1306 OLED screen hardware widget fetching live queries and block counts via Pi-hole API.',
    targetHardware: 'Standalone Desktop Accessory',
    enabledLater: false,
    docReference: 'ION-GF-FE-2026-001 (Section 6)',
  },
];

export const FutureFeatureRoadmap: React.FC = () => {
  const [modules, setModules] = useState<FutureFeatureModule[]>(INITIAL_FUTURE_MODULES);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const toggleModule = (id: string) => {
    setModules((prev) =>
      prev.map((mod) =>
        mod.id === id ? { ...mod, enabledLater: !mod.enabledLater } : mod
      )
    );
  };

  const categories = ['All', 'AI & Intelligence', 'Network Security', 'Hospitality SCADA', 'Travel & Failover', 'Enterprise Hardware'];

  const filteredModules = selectedCategory === 'All'
    ? modules
    : modules.filter((m) => m.category === selectedCategory);

  const activeLaterCount = modules.filter((m) => m.enabledLater).length;

  return (
    <div className="max-w-6xl mx-auto my-6 p-4 sm:p-6 bg-[#0B0F17] text-white rounded-3xl border border-cyan-500/30 shadow-2xl font-sans space-y-6">
      {/* Header */}
      <div className="border-b border-gray-800 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-400" /> Modular Future Expansion Matrix (ADD LATER)
          </h2>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Modular architecture designed for plug-and-play feature additions in future software updates
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-gray-400">Scheduled for Later Phase:</span>
          <span className="bg-amber-500/20 text-amber-400 border border-amber-500/40 px-3 py-1 rounded-xl font-bold">
            {activeLaterCount} / {modules.length} Pre-Configured
          </span>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-gradient-to-r from-cyan-950/60 via-slate-900 to-amber-950/60 p-4 rounded-2xl border border-cyan-500/30 font-mono text-xs text-gray-300 leading-relaxed flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-cyan-300">Phase 1 (Baseline Release):</strong> Runs standard Pi-hole + DNS + Unbound + Autopilot setup as requested.
          <br />
          <strong className="text-amber-300">Phase 2 (Future Modular Additions):</strong> The code structure and API endpoints are built modularly so these advanced capabilities can be toggled on later without altering core baseline stability.
        </div>
      </div>

      {/* Category Filters */}
      <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-mono">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl border whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-amber-500 text-black font-extrabold border-amber-400'
                : 'bg-[#111827] text-gray-400 border-gray-800 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Module Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
        {filteredModules.map((mod) => (
          <div
            key={mod.id}
            className={`p-4 rounded-2xl border transition-all space-y-3 ${
              mod.enabledLater
                ? 'bg-amber-950/20 border-amber-500/50 shadow-lg shadow-amber-500/10'
                : 'bg-[#111827] border-gray-800'
            }`}
          >
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-gray-800 text-amber-400 border border-gray-700">
                  {mod.category}
                </span>
              </div>

              <button
                onClick={() => toggleModule(mod.id)}
                className="text-amber-400 hover:text-amber-300 transition-colors flex items-center gap-1 text-xs"
              >
                {mod.enabledLater ? (
                  <>
                    <ToggleRight className="w-6 h-6 text-amber-400" />
                    <span className="text-[11px] font-bold text-amber-300">Scheduled LATER</span>
                  </>
                ) : (
                  <>
                    <ToggleLeft className="w-6 h-6 text-gray-500" />
                    <span className="text-[11px] text-gray-500">Disabled for Now</span>
                  </>
                )}
              </button>
            </div>

            <div>
              <h3 className="text-sm font-bold text-white font-sans flex items-center gap-1.5">
                {mod.name}
              </h3>
              <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                {mod.description}
              </p>
            </div>

            <div className="pt-2 border-t border-gray-800/80 flex justify-between items-center text-[10px] text-gray-500">
              <span>Target: <strong className="text-gray-300">{mod.targetHardware}</strong></span>
              <span>Doc Ref: <strong className="text-cyan-400">{mod.docReference.split(' ')[0]}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
