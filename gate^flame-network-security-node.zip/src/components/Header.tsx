/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Header Component
 */

import React from 'react';
import { AppViewMode } from '../types';
import { ShieldCheck, Smartphone, Cpu, Server, Terminal, Lock, ExternalLink, Sparkles, Package } from 'lucide-react';

interface HeaderProps {
  currentView: AppViewMode;
  onSelectView: (view: AppViewMode) => void;
  protectionActive: boolean;
  totalBlocked: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onSelectView,
  protectionActive,
  totalBlocked,
}) => {
  return (
    <header className="bg-[#0B0F17] border-b border-cyan-500/30 sticky top-0 z-50 backdrop-blur-md bg-opacity-95 shadow-lg shadow-black/50">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950/80 to-slate-900 text-gray-300 text-[11px] font-mono py-1 px-4 border-b border-gray-800 flex justify-between items-center overflow-x-auto whitespace-nowrap">
        <div className="flex items-center gap-3">
          <span className="text-cyan-400 font-semibold tracking-wider flex items-center gap-1">
            <Lock className="w-3 h-3 text-cyan-400" /> IONITY GLOBAL (Pty) Ltd
          </span>
          <span className="text-gray-500">|</span>
          <span className="text-amber-400">POL 986 AED</span>
          <span className="text-gray-500">|</span>
          <span className="text-emerald-400 font-mono">Gate^Flame™ Network Security Node (v0.1)</span>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <a
            href="https://ionity.co.za/"
            target="_blank"
            rel="noreferrer"
            className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            ionity.co.za <ExternalLink className="w-2.5 h-2.5" />
          </a>
          <a
            href="https://www.ionity.today/"
            target="_blank"
            rel="noreferrer"
            className="text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
          >
            ionity.today <ExternalLink className="w-2.5 h-2.5" />
          </a>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        {/* Logo & Product Mark */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-600 to-indigo-900 flex items-center justify-center text-white shadow-md shadow-cyan-500/20 border border-cyan-400/40">
              <ShieldCheck className="w-6 h-6 text-cyan-200" />
            </div>
            {protectionActive && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white font-sans flex items-center gap-1">
                Gate<span className="text-cyan-400 font-extrabold">^</span>Flame
                <span className="text-[10px] font-mono text-cyan-400 border border-cyan-500/40 bg-cyan-950/60 px-1.5 py-0.5 rounded ml-1">
                  TM
                </span>
              </h1>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-blue-900/60 text-blue-300 border border-blue-500/30">
                DNS Firewall
              </span>
            </div>
            <p className="text-xs text-gray-400 font-mono">
              Digital Perimeter Protection &bull; Ionity Edge Computing System
            </p>
          </div>
        </div>

        {/* Live Protection Summary Badge */}
        <div className="hidden lg:flex items-center gap-3 bg-[#111827] px-3 py-1.5 rounded-lg border border-gray-800 font-mono text-xs">
          <div className="flex flex-col text-right">
            <span className="text-[10px] text-gray-400 uppercase tracking-wider">Gravity Sinkhole</span>
            <span className="text-cyan-400 font-bold">
              {protectionActive ? 'ACTIVE (100% SHIELD)' : 'PAUSED (FAILOVER)'}
            </span>
          </div>
          <div className="h-6 w-px bg-gray-800"></div>
          <div className="flex flex-col">
            <span className="text-[10px] text-gray-400 uppercase tracking-wider">Threats Neutralized</span>
            <span className="text-red-400 font-bold">{totalBlocked.toLocaleString()}</span>
          </div>
        </div>

        {/* Navigation Mode Switcher Buttons */}
        <nav className="flex items-center gap-1.5 bg-[#111827] p-1.5 rounded-xl border border-gray-800 overflow-x-auto">
          <button
            onClick={() => onSelectView('mobile_apk')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentView === 'mobile_apk'
                ? 'bg-cyan-500 text-black font-semibold shadow-md shadow-cyan-500/20'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/80'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile APK App</span>
          </button>

          <button
            onClick={() => onSelectView('device_kiosk')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentView === 'device_kiosk'
                ? 'bg-amber-500 text-black font-semibold shadow-md shadow-amber-500/20'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/80'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Device Onboarding</span>
          </button>

          <button
            onClick={() => onSelectView('server_sync')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentView === 'server_sync'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/20'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/80'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>Server & Sync</span>
          </button>

          <button
            onClick={() => onSelectView('scripts_bom')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentView === 'scripts_bom'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/20'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/80'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Scripts & BOM</span>
          </button>

          <button
            onClick={() => onSelectView('future_roadmap')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentView === 'future_roadmap'
                ? 'bg-amber-500 text-black font-semibold shadow-md shadow-amber-500/20'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/80'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Features (LATER)</span>
          </button>

          <button
            onClick={() => onSelectView('package_export')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              currentView === 'package_export'
                ? 'bg-cyan-500 text-black font-semibold shadow-md shadow-cyan-500/20'
                : 'text-gray-300 hover:text-white hover:bg-gray-800/80'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Packager & Export</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
