/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Mobile APK Command Dashboard
 */

import React, { useState } from 'react';
import { SystemTelemetry, ThreatLogEntry, ConnectedClient, IonityUserAccount } from '../types';
import { GravityParticleCanvas } from './GravityParticleCanvas';
import { 
  ShieldCheck, ShieldAlert, Activity, RefreshCw, Power, Plus, 
  BarChart3, Wifi, Layers, CheckCircle2, Lock, 
  Search, SlidersHorizontal, Moon, Sun, Laptop, Tv, Smartphone, Server
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

interface MobileDashboardProps {
  telemetry: SystemTelemetry;
  threatLogs: ThreatLogEntry[];
  clients: ConnectedClient[];
  userAccount: IonityUserAccount;
  onPauseProtection: (durationMinutes: number) => void;
  onResumeProtection: () => void;
  onAddWhitelistDomain: (domain: string) => void;
  onRefreshGravity: () => void;
  onRebootDevice: () => void;
}

export const MobileDashboard: React.FC<MobileDashboardProps> = ({
  telemetry,
  threatLogs,
  clients,
  userAccount,
  onPauseProtection,
  onResumeProtection,
  onAddWhitelistDomain,
  onRefreshGravity,
  onRebootDevice,
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'threats' | 'clients' | 'settings'>('stats');
  const [whitelistInput, setWhitelistInput] = useState('');
  const [whitelistSuccess, setWhitelistSuccess] = useState<string | null>(null);
  const [isUpdatingGravity, setIsUpdatingGravity] = useState(false);
  const [lightThemePreview, setLightThemePreview] = useState(false);
  const [selectedFilterCategory, setSelectedFilterCategory] = useState<string>('All');

  const handleWhitelistSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!whitelistInput.trim()) return;
    onAddWhitelistDomain(whitelistInput.trim());
    setWhitelistSuccess(`Successfully added '${whitelistInput.trim()}' to Gate^Flame Whitelist`);
    setWhitelistInput('');
    setTimeout(() => setWhitelistSuccess(null), 4000);
  };

  const triggerGravityUpdate = () => {
    setIsUpdatingGravity(true);
    onRefreshGravity();
    setTimeout(() => {
      setIsUpdatingGravity(false);
    }, 2500);
  };

  // Mock chart time-series data
  const chartData = [
    { time: '00:00', total: 1200, blocked: 450 },
    { time: '03:00', total: 800, blocked: 310 },
    { time: '06:00', total: 2400, blocked: 910 },
    { time: '09:00', total: 6800, blocked: 2520 },
    { time: '12:00', total: 9500, blocked: 3510 },
    { time: '15:00', total: 8200, blocked: 3040 },
    { time: '18:00', total: 11200, blocked: 4150 },
    { time: '21:00', total: 7800, blocked: 2890 },
  ];

  const categoryBreakdown = [
    { name: 'Ad Trackers', count: 5820, color: '#00CCFF' },
    { name: 'Telemetry', count: 4210, color: '#3B82F6' },
    { name: 'Malware', count: 2190, color: '#EF4444' },
    { name: 'Phishing', count: 1240, color: '#F59E0B' },
    { name: 'Adult / Gambling', count: 937, color: '#10B981' },
  ];

  const filteredLogs = selectedFilterCategory === 'All'
    ? threatLogs
    : threatLogs.filter(log => log.category === selectedFilterCategory);

  return (
    <div className="max-w-md mx-auto my-4 sm:my-8 bg-[#0B0F17] text-gray-100 rounded-[32px] border-4 border-gray-800 shadow-2xl overflow-hidden relative font-sans flex flex-col min-h-[780px]">
      {/* Mobile Device Status Header */}
      <div className="bg-[#111827] px-6 py-2 flex items-center justify-between text-[11px] font-mono text-gray-400 border-b border-gray-800">
        <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
          <span>Gate^Flame Mobile APK</span>
          <span className="text-[9px] bg-cyan-950 text-cyan-300 px-1 rounded border border-cyan-500/30">v1.0</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-emerald-400 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> Sync: Live
          </span>
          <span>100% 🔋</span>
        </div>
      </div>

      {/* Main Branding Header Bar */}
      <div className={`p-5 border-b transition-colors ${lightThemePreview ? 'bg-slate-100 text-slate-900 border-slate-300' : 'bg-[#0B0F17] text-white border-cyan-500/20'}`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-black font-bold shadow-md shadow-cyan-500/20">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold tracking-tight font-sans">
                Gate<span className="text-cyan-400">^</span>Flame™
              </h2>
              <p className={`text-[10px] font-mono ${lightThemePreview ? 'text-slate-600' : 'text-gray-400'}`}>
                IONITY GLOBAL (Pty) Ltd &bull; POL 986 AED
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded border ${
              telemetry.protectionStatus === 'active'
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-red-500/10 text-red-400 border-red-500/30'
            }`}>
              {telemetry.protectionStatus === 'active' ? 'Shield Active' : 'Paused'}
            </span>
            <p className={`text-[10px] font-mono mt-1 ${lightThemePreview ? 'text-slate-500' : 'text-gray-400'}`}>
              Node: {userAccount.deviceNickname.split('#')[0]}
            </p>
          </div>
        </div>

        {/* Subheader info pill */}
        <div className={`text-[11px] font-mono px-3 py-1.5 rounded-lg flex justify-between items-center ${
          lightThemePreview ? 'bg-slate-200 text-slate-700' : 'bg-[#111827] text-gray-300 border border-gray-800'
        }`}>
          <span className="flex items-center gap-1.5">
            <Lock className="w-3 h-3 text-cyan-400" /> Subscription: <strong className="text-emerald-400">R45/mo Warranty</strong>
          </span>
          <span className="text-[10px] text-cyan-400 font-semibold">6.7M Domains</span>
        </div>
      </div>

      {/* Dynamic Tab Navigation */}
      <div className="grid grid-cols-4 bg-[#111827] border-b border-gray-800 text-xs font-mono text-center">
        <button
          onClick={() => setActiveTab('stats')}
          className={`py-2.5 flex flex-col items-center gap-1 border-b-2 transition-all ${
            activeTab === 'stats'
              ? 'border-cyan-400 text-cyan-400 font-bold bg-cyan-950/30'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span className="text-[10px]">Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('threats')}
          className={`py-2.5 flex flex-col items-center gap-1 border-b-2 transition-all ${
            activeTab === 'threats'
              ? 'border-red-400 text-red-400 font-bold bg-red-950/30'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span className="text-[10px]">Threat Logs</span>
        </button>

        <button
          onClick={() => setActiveTab('clients')}
          className={`py-2.5 flex flex-col items-center gap-1 border-b-2 transition-all ${
            activeTab === 'clients'
              ? 'border-amber-400 text-amber-400 font-bold bg-amber-950/30'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <Wifi className="w-4 h-4" />
          <span className="text-[10px]">Devices ({clients.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`py-2.5 flex flex-col items-center gap-1 border-b-2 transition-all ${
            activeTab === 'settings'
              ? 'border-purple-400 text-purple-400 font-bold bg-purple-950/30'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span className="text-[10px]">Settings</span>
        </button>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* TAB 1: INFOGRAPHIC DASHBOARD */}
        {activeTab === 'stats' && (
          <div className="space-y-4">
            {/* Live Gravity Engine Particle Shield */}
            <div>
              <GravityParticleCanvas isPaused={telemetry.protectionStatus !== 'active'} />
            </div>

            {/* 4-Panel Boxed Telemetry Grid ("Stats1.jpg" Aesthetic) */}
            <div className="grid grid-cols-2 gap-3 font-mono">
              {/* Total Queries (Blue) */}
              <div className="bg-[#111827] p-3.5 rounded-2xl border border-blue-500/30 shadow-md">
                <div className="flex justify-between items-center text-blue-400 mb-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider">Total Queries</span>
                  <Activity className="w-4 h-4" />
                </div>
                <div className="text-xl font-extrabold text-blue-400 tracking-tight">
                  {telemetry.totalQueriesToday.toLocaleString()}
                </div>
                <div className="text-[10px] text-gray-400 mt-1">24hr DNS Activity</div>
              </div>

              {/* Queries Blocked (Red) */}
              <div className="bg-[#111827] p-3.5 rounded-2xl border border-red-500/30 shadow-md">
                <div className="flex justify-between items-center text-red-400 mb-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider">Queries Blocked</span>
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div className="text-xl font-extrabold text-red-400 tracking-tight">
                  {telemetry.queriesBlockedToday.toLocaleString()}
                </div>
                <div className="text-[10px] text-gray-400 mt-1">Sinkholed Requests</div>
              </div>

              {/* Block Percentage (Orange) */}
              <div className="bg-[#111827] p-3.5 rounded-2xl border border-amber-500/30 shadow-md">
                <div className="flex justify-between items-center text-amber-400 mb-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider">Block Rate</span>
                  <Layers className="w-4 h-4" />
                </div>
                <div className="text-xl font-extrabold text-amber-400 tracking-tight">
                  {telemetry.blockPercentage}%
                </div>
                <div className="text-[10px] text-emerald-400 mt-1">37.1% Data Waste Saved</div>
              </div>

              {/* Domains on Gravity (Green) */}
              <div className="bg-[#111827] p-3.5 rounded-2xl border border-emerald-500/30 shadow-md">
                <div className="flex justify-between items-center text-emerald-400 mb-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider">Gravity Count</span>
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div className="text-lg font-extrabold text-emerald-400 tracking-tight">
                  {(telemetry.domainsOnGravity / 1000000).toFixed(2)}M
                </div>
                <div className="text-[10px] text-gray-400 mt-1">Active Global Blocklists</div>
              </div>
            </div>

            {/* Live Chart: DNS Volume over Time */}
            <div className="bg-[#111827] p-4 rounded-2xl border border-gray-800">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-1.5">
                  <BarChart3 className="w-3.5 h-3.5" /> 24-Hour Traffic Infographic
                </h3>
                <span className="text-[10px] font-mono text-gray-400">Blue=Queries | Red=Blocked</span>
              </div>
              <div className="h-36 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="totalColor" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="blockedColor" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#EF4444" stopOpacity={0.6} />
                        <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="time" stroke="#4B5563" fontSize={10} tickLine={false} />
                    <YAxis stroke="#4B5563" fontSize={10} tickLine={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#374151', borderRadius: '8px', fontSize: '11px' }}
                    />
                    <Area type="monotone" dataKey="total" stroke="#3B82F6" fillOpacity={1} fill="url(#totalColor)" />
                    <Area type="monotone" dataKey="blocked" stroke="#EF4444" fillOpacity={1} fill="url(#blockedColor)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Quick Controllers Section */}
            <div className="bg-[#111827] p-4 rounded-2xl border border-gray-800 space-y-3">
              <h3 className="text-xs font-bold font-mono text-white flex items-center gap-1.5">
                <Power className="w-3.5 h-3.5 text-cyan-400" /> Active Remote Controllers
              </h3>

              {telemetry.protectionStatus === 'active' ? (
                <div className="flex gap-2">
                  <button
                    onClick={() => onPauseProtection(5)}
                    className="flex-1 bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-500/40 py-2 rounded-xl text-xs font-mono font-medium transition-all"
                  >
                    Pause 5m
                  </button>
                  <button
                    onClick={() => onPauseProtection(15)}
                    className="flex-1 bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-500/40 py-2 rounded-xl text-xs font-mono font-medium transition-all"
                  >
                    Pause 15m
                  </button>
                  <button
                    onClick={() => onPauseProtection(60)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-gray-200 border border-gray-700 py-2 rounded-xl text-xs font-mono font-medium transition-all"
                  >
                    Pause 1h
                  </button>
                </div>
              ) : (
                <button
                  onClick={onResumeProtection}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold py-2.5 rounded-xl text-xs font-mono shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" /> RESUME GATE^FLAME PROTECTION NOW
                </button>
              )}

              {/* Instant Whitelist Domain Form */}
              <form onSubmit={handleWhitelistSubmit} className="pt-2 border-t border-gray-800">
                <label className="block text-[11px] font-mono text-gray-300 mb-1.5">
                  Instant Domain Whitelist:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={whitelistInput}
                    onChange={(e) => setWhitelistInput(e.target.value)}
                    placeholder="e.g. work-portal.com"
                    className="flex-1 bg-[#0B0F17] border border-gray-700 rounded-xl px-3 py-1.5 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    className="bg-cyan-500 hover:bg-cyan-400 text-black px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add
                  </button>
                </div>
                {whitelistSuccess && (
                  <p className="text-[11px] font-mono text-emerald-400 mt-1.5 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> {whitelistSuccess}
                  </p>
                )}
              </form>
            </div>
          </div>
        )}

        {/* TAB 2: THREAT LOGS & CATEGORIES */}
        {activeTab === 'threats' && (
          <div className="space-y-4">
            {/* Category Breakdown Bar Chart */}
            <div className="bg-[#111827] p-4 rounded-2xl border border-gray-800">
              <h3 className="text-xs font-bold font-mono text-cyan-400 mb-3 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-red-400" /> Neutralized Threat Breakdown
              </h3>
              <div className="h-40 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryBreakdown} layout="vertical" margin={{ top: 0, right: 10, left: 20, bottom: 0 }}>
                    <XAxis type="number" stroke="#4B5563" fontSize={10} hide />
                    <YAxis dataKey="name" type="category" stroke="#9CA3AF" fontSize={10} width={90} tickLine={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0B0F17', borderColor: '#374151', borderRadius: '8px', fontSize: '11px' }}
                    />
                    <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                      {categoryBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-[10px] font-mono">
              {['All', 'Telemetry', 'Ad Tracker', 'Phishing', 'Cryptojacking', 'Adult / Gambling'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedFilterCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg border whitespace-nowrap transition-all ${
                    selectedFilterCategory === cat
                      ? 'bg-cyan-500 text-black font-bold border-cyan-400'
                      : 'bg-[#111827] text-gray-400 border-gray-800 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Threat Feed List */}
            <div className="bg-[#111827] rounded-2xl border border-gray-800 divide-y divide-gray-800/60 overflow-hidden">
              <div className="p-3 bg-[#0B0F17] flex justify-between items-center text-[10px] font-mono text-gray-400">
                <span>RECENT REAL-TIME LOGS</span>
                <span>TOTAL: {filteredLogs.length}</span>
              </div>

              {filteredLogs.map((log) => (
                <div key={log.id} className="p-3 hover:bg-gray-800/40 transition-colors">
                  <div className="flex justify-between items-start">
                    <div className="font-mono text-xs font-semibold text-gray-200 truncate max-w-[200px]">
                      {log.domain}
                    </div>
                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border uppercase ${
                      log.action === 'Blocked'
                        ? 'bg-red-950/80 text-red-400 border-red-500/40'
                        : 'bg-emerald-950/80 text-emerald-400 border-emerald-500/40'
                    }`}>
                      {log.action}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-400 mt-1.5">
                    <span>Client: <strong className="text-gray-300">{log.clientName}</strong></span>
                    <span className="text-amber-400/90">{log.category}</span>
                    <span className="text-gray-500">{log.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CONNECTED CLIENT DEVICES */}
        {activeTab === 'clients' && (
          <div className="space-y-3 font-mono">
            <div className="bg-[#111827] p-3 rounded-2xl border border-gray-800 flex justify-between items-center text-xs">
              <div>
                <span className="text-gray-400">Protected Client Nodes: </span>
                <strong className="text-cyan-400">{clients.length} Active</strong>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                Zero-Touch Routing
              </span>
            </div>

            {clients.map((cli) => {
              const IconComp = 
                cli.deviceType === 'TV' ? Tv :
                cli.deviceType === 'Laptop' ? Laptop :
                cli.deviceType === 'Smartphone' ? Smartphone : Server;

              return (
                <div key={cli.mac} className="bg-[#111827] p-3.5 rounded-2xl border border-gray-800 hover:border-cyan-500/40 transition-all space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-lg bg-gray-800 text-cyan-400">
                        <IconComp className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">{cli.hostname}</div>
                        <div className="text-[10px] text-gray-400">{cli.ip} &bull; {cli.mac}</div>
                      </div>
                    </div>
                    <span className="text-[10px] text-gray-400">{cli.lastActive}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-800/60 text-[11px]">
                    <div className="bg-[#0B0F17] p-2 rounded-lg border border-gray-800 text-center">
                      <div className="text-[9px] text-gray-400">Queries Today</div>
                      <div className="text-blue-400 font-bold">{cli.queriesToday.toLocaleString()}</div>
                    </div>
                    <div className="bg-[#0B0F17] p-2 rounded-lg border border-gray-800 text-center">
                      <div className="text-[9px] text-gray-400">Threats Neutralized</div>
                      <div className="text-red-400 font-bold">{cli.blockedToday.toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 4: LIGHT SETTINGS */}
        {activeTab === 'settings' && (
          <div className="space-y-4 font-mono text-xs">
            {/* Theme & Skins */}
            <div className="bg-[#111827] p-4 rounded-2xl border border-gray-800 space-y-3">
              <h3 className="font-bold text-cyan-400 flex items-center gap-1.5">
                <Sun className="w-4 h-4" /> Visual Theme & Skins
              </h3>
              <div className="flex justify-between items-center text-gray-300">
                <span>Light Theme Mobile Skin:</span>
                <button
                  onClick={() => setLightThemePreview(!lightThemePreview)}
                  className={`px-3 py-1 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 ${
                    lightThemePreview
                      ? 'bg-amber-400 text-black border-amber-300'
                      : 'bg-gray-800 text-gray-300 border-gray-700'
                  }`}
                >
                  {lightThemePreview ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                  {lightThemePreview ? 'Light Mode' : 'Dark Mode'}
                </button>
              </div>
              <p className="text-[10px] text-gray-400 leading-relaxed">
                Matches the brand-specific look and feel from ionity.today and ionity.co.za.
              </p>
            </div>

            {/* Hardware Maintenance Operations */}
            <div className="bg-[#111827] p-4 rounded-2xl border border-gray-800 space-y-3">
              <h3 className="font-bold text-amber-400 flex items-center gap-1.5">
                <RefreshCw className="w-4 h-4" /> Node Operations
              </h3>

              <div className="space-y-2">
                <button
                  onClick={triggerGravityUpdate}
                  disabled={isUpdatingGravity}
                  className="w-full bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCw className={`w-4 h-4 ${isUpdatingGravity ? 'animate-spin' : ''}`} />
                  {isUpdatingGravity ? 'Ingesting Weekly Blocklists...' : 'Force Gravity Database Update'}
                </button>

                <button
                  onClick={onRebootDevice}
                  className="w-full bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-500/40 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                >
                  <Power className="w-4 h-4" /> Reboot Gate^Flame Physical Node
                </button>
              </div>
            </div>

            {/* Legal Marks & Device Info */}
            <div className="bg-[#111827] p-4 rounded-2xl border border-gray-800 space-y-2 text-[10px] text-gray-400">
              <div className="text-white font-bold text-xs flex items-center gap-1">
                <Lock className="w-3 h-3 text-cyan-400" /> Ionity Global (Pty) Ltd Legal Marks
              </div>
              <p>Model: Gate^Flame™ Network Security Node</p>
              <p>Serial / MAC: DC:A6:32:88:14:2F</p>
              <p>Registered Mark: ION-GF-PD-2026-008 (POL 986 AED)</p>
              <p className="text-emerald-400">Active Subscription: R45.00 / month (2-Year Warranty Active)</p>
            </div>
          </div>
        )}
      </div>

      {/* Footer Branding Bar */}
      <div className="bg-[#0B0F17] p-3 text-center border-t border-gray-800 text-[10px] font-mono text-gray-500">
        &copy; 2026 Ionity Global (Pty) Ltd. All Rights Reserved. Gate^Flame™
      </div>
    </div>
  );
};
