/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Ionity Global (Pty) Ltd — Server & Sync Architecture ("The Hook-Up")
 */

import React, { useState } from 'react';
import { IonityUserAccount, HardwareTierId } from '../types';
import { HARDWARE_TIERS } from '../data/mockData';
import { 
  Server, Smartphone, Cpu, RefreshCw, Key, CheckCircle2, 
  Lock, Zap, ArrowRightLeft, ShieldCheck
} from 'lucide-react';

interface ServerSyncArchitectureProps {
  userAccount: IonityUserAccount;
  onUpdateUserAccount: (updated: Partial<IonityUserAccount>) => void;
}

export const ServerSyncArchitecture: React.FC<ServerSyncArchitectureProps> = ({
  userAccount,
  onUpdateUserAccount,
}) => {
  const [selectedTierId, setSelectedTierId] = useState<HardwareTierId>('tier3_visual');
  const [isTestingApi, setIsTestingApi] = useState(false);
  const [apiResponseJson, setApiResponseJson] = useState<string | null>(null);

  const handleTestApiCall = () => {
    setIsTestingApi(true);
    setApiResponseJson(null);
    setTimeout(() => {
      setIsTestingApi(false);
      setApiResponseJson(JSON.stringify({
        status: "success",
        node_mac: userAccount.linkedDeviceMac,
        dns_queries_today: "38,851",
        ads_blocked_today: "14,397",
        ads_percentage_today: "37.1%",
        domains_being_blocked: "6,755,558",
        unbound_status: "active_recursive",
        subscription_warranty: "active_r45_zar",
        gravity_last_updated: "2026-07-20 04:00:00"
      }, null, 2));
    }, 1200);
  };

  const selectedTier = HARDWARE_TIERS.find((t) => t.id === selectedTierId) || HARDWARE_TIERS[2];

  return (
    <div className="max-w-6xl mx-auto my-6 p-4 sm:p-6 bg-[#0B0F17] text-white rounded-3xl border border-cyan-500/30 shadow-2xl font-sans space-y-6">
      {/* Title & Architecture Overview Header */}
      <div className="border-b border-gray-800 pb-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Server className="w-6 h-6 text-cyan-400" /> Server & Sync Architecture ("The Hook-Up")
            </h2>
            <p className="text-xs text-gray-400 font-mono mt-1">
              Automated Zero-Trust Sync Pipeline between Mobile App, Centralized Ionity Server & Gate^Flame Physical Node
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-gray-400">Sync Status:</span>
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2.5 py-1 rounded-xl font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span> Real-Time mTLS Synced
            </span>
          </div>
        </div>
      </div>

      {/* Visual System Architecture Diagram */}
      <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-4">
        <h3 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" /> Distributed 3-Tier Data Sync Pipeline
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {/* Node 1: Mobile App */}
          <div className="bg-[#0B0F17] p-4 rounded-xl border border-cyan-500/30 space-y-2 relative">
            <div className="flex justify-between items-center text-cyan-400 font-bold">
              <span className="flex items-center gap-1.5"><Smartphone className="w-4 h-4" /> 1. Mobile APK App</span>
              <span className="text-[10px] bg-cyan-950 px-1.5 py-0.5 rounded border border-cyan-500/30">Client</span>
            </div>
            <p className="text-[11px] text-gray-400">
              Streams live telemetry metrics, renders dark mode infographics, sends remote pause/whitelist commands.
            </p>
            <div className="text-[10px] text-gray-500 pt-1 border-t border-gray-800">
              OAuth Token: <code className="text-cyan-300">{userAccount.apiKey.slice(0, 12)}...</code>
            </div>
          </div>

          {/* Sync Tunnel Arrows */}
          <div className="bg-[#0B0F17] p-4 rounded-xl border border-blue-500/30 space-y-2 relative">
            <div className="flex justify-between items-center text-blue-400 font-bold">
              <span className="flex items-center gap-1.5"><Server className="w-4 h-4" /> 2. Ionity Central Server</span>
              <span className="text-[10px] bg-blue-950 px-1.5 py-0.5 rounded border border-blue-500/30">Cloud Bridge</span>
            </div>
            <p className="text-[11px] text-gray-400">
              Validates R45/mo warranty subscription, pushes weekly Gravity updates, orchestrates zero-trust mTLS.
            </p>
            <div className="text-[10px] text-gray-500 pt-1 border-t border-gray-800">
              Endpoint: <code className="text-blue-300">api.ionity.today/v1/sync</code>
            </div>
          </div>

          {/* Node 3: Physical Device */}
          <div className="bg-[#0B0F17] p-4 rounded-xl border border-emerald-500/30 space-y-2 relative">
            <div className="flex justify-between items-center text-emerald-400 font-bold">
              <span className="flex items-center gap-1.5"><Cpu className="w-4 h-4" /> 3. Gate^Flame Physical Node</span>
              <span className="text-[10px] bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-500/30">Edge Node</span>
            </div>
            <p className="text-[11px] text-gray-400">
              Executes Pi-hole + DNS + Unbound recursion locally. Runs autopilot failover hotspot if internet drops.
            </p>
            <div className="text-[10px] text-gray-500 pt-1 border-t border-gray-800">
              MAC: <code className="text-emerald-300">{userAccount.linkedDeviceMac}</code>
            </div>
          </div>
        </div>
      </div>

      {/* Account Sync & Subscription Management */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Account Details & API Key */}
        <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-4 font-mono text-xs">
          <h3 className="font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-cyan-400" /> Client Account & Authentication State
          </h3>

          <div className="space-y-2.5">
            <div>
              <span className="text-gray-400">Account Owner:</span>
              <div className="text-cyan-300 font-bold text-sm">{userAccount.email}</div>
            </div>

            <div>
              <span className="text-gray-400">Linked Physical Device:</span>
              <div className="text-white font-bold">{userAccount.deviceNickname} ({userAccount.linkedDeviceMac})</div>
            </div>

            <div>
              <span className="text-gray-400">Central API Authentication Token:</span>
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  readOnly
                  value={userAccount.apiKey}
                  className="flex-1 bg-[#0B0F17] border border-gray-700 rounded-xl px-3 py-1.5 text-cyan-400 font-mono text-xs"
                />
                <button
                  onClick={() => onUpdateUserAccount({ apiKey: `gf_live_ionity_${Math.random().toString(36).substring(2, 9)}` })}
                  className="p-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl border border-gray-700"
                  title="Rotate Token"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Subscription & Warranty Card */}
        <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-4 font-mono text-xs">
          <h3 className="font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Operational Maintenance & Subscription
          </h3>

          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl space-y-1.5">
            <div className="flex justify-between items-center text-emerald-400 font-bold">
              <span>Subscription Status: ACTIVE</span>
              <span className="text-white bg-emerald-600 px-2 py-0.5 rounded text-[10px]">R45.00 / month</span>
            </div>
            <p className="text-[11px] text-gray-300">
              Includes weekly Gravity blocklist updates (6.7M+ domains) & 2-Year Full Hardware Warranty.
            </p>
            <div className="text-[10px] text-gray-400 pt-1">
              Warranty Valid Until: <strong className="text-white">{userAccount.warrantyValidUntil}</strong>
            </div>
          </div>

          <div className="text-[11px] text-gray-400 leading-relaxed">
            Ionity Global (Pty) Ltd manages the complex backend maintenance automatically, guaranteeing zero-touch deployment and software support.
          </div>
        </div>
      </div>

      {/* Interactive API Endpoint Tester */}
      <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-4 font-mono text-xs">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-cyan-400 flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4" /> Live Mobile-to-Node API Endpoint Tester
          </h3>

          <button
            onClick={handleTestApiCall}
            disabled={isTestingApi}
            className="bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold px-4 py-1.5 rounded-xl transition-all shadow-md shadow-cyan-500/20 flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isTestingApi ? 'animate-spin' : ''}`} />
            {isTestingApi ? 'Executing API Request...' : 'Test GET /admin/api.php?summary'}
          </button>
        </div>

        <div className="bg-[#0B0F17] p-3 rounded-xl border border-gray-800 font-mono text-[11px]">
          <div className="text-gray-400 mb-1">
            Request URL: <span className="text-cyan-300">http://192.168.1.105/admin/api.php?summary&auth={userAccount.apiKey}</span>
          </div>

          {apiResponseJson && (
            <pre className="mt-2 p-3 bg-slate-950 rounded-lg text-emerald-400 overflow-x-auto text-[10px] leading-snug">
              {apiResponseJson}
            </pre>
          )}
        </div>
      </div>

      {/* Hardware Tiers Comparison & Sourcing Matrix */}
      <div className="bg-[#111827] p-5 rounded-2xl border border-gray-800 space-y-4 font-mono text-xs">
        <h3 className="font-bold text-amber-400 flex items-center gap-2">
          <Cpu className="w-4 h-4" /> Gate^Flame Hardware Tier Portfolio
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {HARDWARE_TIERS.map((tier) => (
            <div
              key={tier.id}
              onClick={() => setSelectedTierId(tier.id)}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all space-y-2 ${
                selectedTierId === tier.id
                  ? 'bg-amber-950/40 border-amber-400 shadow-md shadow-amber-500/10'
                  : 'bg-[#0B0F17] border-gray-800 hover:border-gray-700'
              }`}
            >
              <div className="flex justify-between items-start">
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${tier.badgeColor}`}>
                  {tier.id.toUpperCase()}
                </span>
                <span className="text-amber-400 font-bold">R{tier.retailPriceZAR.toFixed(2)}</span>
              </div>

              <div className="font-bold text-white text-xs leading-snug">{tier.name}</div>
              <div className="text-[10px] text-gray-400 leading-tight">{tier.subtitle}</div>

              <div className="text-[10px] text-gray-500 pt-2 border-t border-gray-800 space-y-0.5">
                <p>CPU: {tier.cpu.split('@')[0]}</p>
                <p>QPS Capacity: ~{tier.qps}</p>
                <p>Max Clients: {tier.maxClients}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
